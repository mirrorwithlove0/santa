def on_download_start(api, gid):
    print("started " + gid)


def on_download_pause(api, gid):
    print("paused " + gid)
